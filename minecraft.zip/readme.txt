﻿#####################################################################
			Installationsanleitung
#####################################################################

Gehe die Intallationsanleitung von oben nach unten durch. Wenn ein Punkt nicht klappt gehe zur nächsten Installationsart

	• Du findest in der Zip-Datei drei Programme.
		► Minecraft.exe				(Minecraft Cracked Version)
		► MinecraftInstaller.msi		(Offizielle Minecraft Version)
		► MCLeaksAuthenticator.exe		(Programm um Zertifikat zu fälschen)

Möglichkeiten zu Spielen (Installationsarten):
1.) • Du hast einen eigenen Account
2.) • Du benutzt die Minecraft.exe
3.) • Wenn du über die Minecraft.exe nicht spielen kannst, installiere über "MCLeaksAuthenticator.exe" ein gefälschtes Zertifikat und Spiele mit dem Namen den du bei Minecraft.exe eingegeben hast
4.) • Wenn das nicht klappt, gebe beim Benutzernamen den Altcode von mcleaks.net ein und denk dir irgend ein Passwort aus
5.) • Wenn das nicht klappt, benutze einen Account, den du unter "Hilfe ► Ich habe keinen Minecraft Account" findest

#####################################################################

1.) • Du hast einen eigenen Account
	• Wenn du einen eigenen Minecraft Account besitzt und über diesen spielen möchtest, benötigst du nur die "MinecraftInstaller.msi"
	• Führe diese aus und gehe durch den Installationsvorgang
	• Öffne Minecraft, melde dich an und starte das Spiel auf der neusten Version (Bzw. auf 1.13.2)
	• Klicke auf Multiplayer und anschließend auf "Ad Server"
	• Beim Servernamen, ist dir der Name selber überlassen
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche ein)
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done"
	• Nun kannst du dem Server beitreten.

2.) • Du benutzt die Minecraft.exe
	• Wenn du keinen eigenen Minecraft Account besitzt und/oder du dir deinen Namen selbst aussuchen möchtest, benutze die Datei "Minecraft.exe"
	• Diese öffnest du ganz normal. Wenn eine Fehlermeldung auftaucht, wie "Outdated launcher", ignoriere diese und klicke auf "I'm sure. Reset my settings."
	• Gebe anschließend einen Namen deiner Wahl ein, klicke auf "Options" und klicke das Häkchen "Stay Logged In" an. Achte darauf, dass wenn du einmal mit diesem Namen auf dem Server warst, dass du deinen Namen nicht mehr änderst, weil sonnst deine Items verschwinden können.
	• Stelle nun ein, dass du auf der neusten Version (Bzw. Version 1.13.2) spielen möchtest und klicke auf "Play".
	• !!!Es kann sein, dass Minecraft abstürzt. Schaue dir dazu die nächste installationsart an. Das kann besonders bei Windows 10 Geräten mit einem Intel HD Grafikchip passieren, weil dieser nicht so gut mit Windows 10 kompartiebel ist.
	• Wenn keine Fehlermeldung kommt und sich das Spiel ganz normal öffnet, klicke auf Multiplayer und anschließend auf "Ad Server"
	• Beim Servernamen, ist dir der Name selber überlassen
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done"
	• Nun kannst du dem Server beitreten.

3.) • Wenn du über die Minecraft.exe nicht spielen kannst, aber dennoch einen selbst ausgesuchten Namen verwenden möchtest
	• In diesem Falle, benutzt du doch die "MinecraftInstaller.msi".
	• Da du ja keinen normalen Minecraft Account hast, öffnest du Minecraft nach dem installationsvorgang erstmal nicht.
	• Anschließend öffnest du das Programm "MCLeaktsAuthenticator.exe" und klickst auf den blauen Button "MCLeaks"
	• Es öffnet sich ein Fenster in dem du das Programm "Minecraft" auswählen sollst. Dieses befindet sich üblicherweise unter "C:\Program Files (x86)\Minecraft\" und hat den Dateinamen "MinecraftLauncher.exe"
	• Es öffnet sich ein neues Fenster mit einer Sicherheitwarnung und du wirst gefragt, ob du dieses Zertifikat installieren möchtest. Klicke hier auf "Ja"
	• Nun kannst du das Programm wieder schließen und Minecraft starten.
	• Im Optimalen Falle, müsstest du unter dem Namen angemeldet sein unter dem du dich schon bei dem Punkt "• Du benutzt die Minecraft.exe" probiert hast anzumelden.
	• Wenn du nicht angemeltet sein solltest, schaue dir die nächste installationsart an.
	• Stelle nun ein, dass du auf der neusten Version (Bzw. Version 1.13.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server"
	• Beim Servernamen, ist dir der Name selber überlassen
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done"
	• Nun kannst du dem Server beitreten.

4.) • Wenn du bei der vorherungen installationsart nicht eingeloggt warst, kannst du dir einen Alt-Code von mcleaks.net holen.
	• Da du ja keinen normalen Minecraft Account hast, gibt es die möglichkeit einen geleakten zu nehmen, oder dich beispielsweise mit einem Alt-Token von mcleaks.net zu verifizieren.
	• Klicke auf mcleaks.net in der Mitte auf den Button "MC Account jetzt erhalten", bestätige das reCAPCHA und es wird der Alt-Token angezeigt.
	• Diesen kopierst du in die Zwischenablage
	• Gebe beim Benutzeraccount nun den Alt Code ein und irgend ein Passwort.
	• Wenn du dich so nicht anmelden kannst, gehe weiter zur letzten Installationsart.
	• Stelle ansonnsten nun ein, dass du auf der neusten Version (Bzw. Version 1.13.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server"
	• Beim Servernamen, ist dir der Name selber überlassen
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done"
	• Nun kannst du dem Server beitreten.

5.) • Wenn alle anderen Installationsarten gescheitert sind
	• Auf der Seite mindecraft.lan-party.ml findest du unter dem Punkt Hilfe ► Ich habe keinen Minecraft Account, geleakte daten. Spreche dich allerdings mit anderen Spielern auf dem Server ab, dass ihr nicht die gleichn nehmt, weil ihr euch sonnst gegenseitig rauswerft.
	• Melde dich damit bei Minecraft an
	• Wenn das nicht klappt, probiere einen anderen Account aus. Wenn es mit keinem aller Accounts klappt schaue unten bei Hilfe nach.
	• Wenn du dich einloggen konntest, stelle nun ein, dass du auf der neusten Version (Bzw. Version 1.13.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server"
	• Beim Servernamen, ist dir der Name selber überlassen
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done"
	• Nun kannst du dem Server beitreten.

#####################################################################
				Hilfe
#####################################################################
	Was tun, wenn keine Installationsart geklappt hat?
	• Alle Programme neu installieren
	• Die Anleitung von oben nach unten schritt für Schritt durchgehen
	• Java Version überprüfen (Mindestens Version 8)
	• den "C:\Users\DEINNUTZERNAME\AppData\Roaming\.minecraft" Ordner löschen
	• Probieren Minecraft in der Version 1.12.2 zu starten
	• Wenn das alles nicht hilft, kann es sein, dass dein PC zu schlecht ist.
