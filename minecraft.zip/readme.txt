﻿#####################################################################
			Installationsanleitung
#####################################################################

Gehe die Installationsanleitung von oben nach unten durch. Wenn ein Punkt nicht klappt, gehe zur nächsten Installationsart.

	• Du findest in der Zip-Datei sechs (bzw. sieben) Programme.
		► Minecraft.exe				(Minecraft Cracked Version)
		► MinecraftInstaller.msi	(Offizielle Minecraft Version)
		► MCLeaksAuthenticator.exe	(Programm um Zertifikat zu fälschen)
		► forge.exe					(Installationsdatei um Minecraft mit Mods laufen zu lassen bzw. um InventoryTweaks als Mod laufen zu lassen)
		► Java_8_32-bit.exe			(Java installation für 32-bit Systeme (im zweifel das nehmen))
		► Java_8_64-bit.exe			(Java installation für 64-bit Systeme)
	   (► InventoryTweaks-1.63.jar) (Datei die in den /.minecraft/mods/ Ordner verschoben werden muss)

Möglichkeiten zu Spielen (Installationsarten):
1.) • Du hast einen eigenen Account.
2.) • Du benutzt die Minecraft.exe.
3.) • Wenn du über die Minecraft.exe nicht spielen kannst, installiere über "MCLeaksAuthenticator.exe" ein gefälschtes Zertifikat und Spiele mit dem Namen, den du bei Minecraft.exe eingegeben hast.
4.) • Wenn das nicht klappt, gebe beim Benutzernamen den Alt-Token von mcleaks.net ein und denk dir irgend ein Passwort aus.
5.) • Wenn das nicht klappt, benutze einen Account, den du unter "Hilfe ► Ich habe keinen Minecraft Account" findest.

#####################################################################
Vorinstallation:

	• Mache deinen Computer am besten schon einige Zeit vorher an, damit er sich sortieren kann.
	• Finde heraus, welches Bit-System dein Computer hat.
	• Wenn du ein 64-bit System hast, installiere "Java_8_64-bit.exe".
	• Wenn du ein 32-bit System hast oder dir nicht sicher bist, installiere "Java_8_32-bit.exe".
	• Für eine gute Grafikleistung, achte darauf, dass du die neusten Windows Updates gemacht hast.
	• Um deinen PC schneller zu machen, kannst du unter dem Punkt "Autostart", bei deinem Taskmanager alles deaktivieren und den PC neustarten.

#####################################################################

1.) • Du hast einen eigenen Account.
	• Wenn du einen eigenen Minecraft Account besitzt und über diesen spielen möchtest, benötigst du nur die "MinecraftInstaller.msi".
	• Führe diese aus und gehe durch den Installationsvorgang.
	• Öffne Minecraft, melde dich an und starte das Spiel auf der viertneusten Version (Bzw. auf 1.12.2).
	• Klicke auf Multiplayer und anschließend auf "Ad Server".
	• Beim Servernamen, ist dir der Name selber überlassen.
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein.
	• Bei den Server Resource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done".
	• Nun kannst du dem Server beitreten.

2.) • Du benutzt die Minecraft.exe.
	• Wenn du keinen eigenen Minecraft Account besitzt und du dir deinen Namen selbst aussuchen möchtest, benutze die Datei "Minecraft.exe".
	• Diese öffnest du ganz normal. Wenn eine Fehlermeldung auftaucht, wie "Outdated launcher", ignoriere diese und klicke auf "I'm sure. Reset my settings.".
	• Gebe anschließend einen Namen deiner Wahl ein, klicke auf "Options" und klicke das Häkchen "Stay Logged In" an. Achte darauf, dass wenn du einmal mit diesem Namen auf dem Server warst, dass du deinen Namen nicht mehr änderst, weil sonnst deine Items verschwinden können.
	• Stelle nun ein, dass du auf der viertneusten Version (Bzw. Version 1.12.2) spielen möchtest und klicke auf "Play".
	• Es kann sein, dass Minecraft abstürzt. Schaue dir dazu die nächste Installationsart an. Das kann besonders bei Windows 10 Geräten mit einem Intel HD Grafikchip passieren, weil dieser nicht so gut mit Windows 10 kompatibel ist.
	• Wenn keine Fehlermeldung kommt und sich das Spiel ganz normal öffnet, klicke auf Multiplayer und anschließend auf "Ad Server".
	• Beim Servernamen, ist dir der Name selber überlassen.
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein.
	• Bei den Server Resource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done".
	• Nun kannst du dem Server beitreten.

3.) • Wenn du über die Minecraft.exe nicht spielen kannst, aber dennoch einen selbst ausgesuchten Namen verwenden möchtest.
	• In diesem Falle, benutzt du doch die "MinecraftInstaller.msi".
	• Da du ja keinen normalen Minecraft Account hast, öffnest du Minecraft nach dem Installationsvorgang erstmal nicht.
	• Anschließend öffnest du das Programm "MCLeaktsAuthenticator.exe" und klickst auf den blauen Button "MCLeaks".
	• Es öffnet sich ein Fenster in dem du das Programm "Minecraft" auswählen sollst. Dieses befindet sich üblicherweise unter "C:\Program Files (x86)\Minecraft\" und hat den Dateinamen "MinecraftLauncher.exe".
	• Es öffnet sich ein neues Fenster mit einer Sicherheit Warnung und du wirst gefragt, ob du dieses Zertifikat installieren möchtest. Klicke hier auf "Ja".
	• Nun kannst du das Programm wieder schließen und Minecraft starten.
	• Im optimalen Falle, müsstest du unter dem Namen angemeldet sein unter dem du dich schon bei dem Punkt "• Du benutzt die Minecraft.exe" probiert hast anzumelden.
	• Wenn du nicht angemeldet sein solltest, schaue dir die nächste Installationsart an.
	• Stelle nun ein, dass du auf der viertneusten Version (Bzw. Version 1.12.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server".
	• Beim Servernamen, ist dir der Name selber überlassen.
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein.
	• Bei den Server Resource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done".
	• Nun kannst du dem Server beitreten.

4.) • Wenn du bei der vorherigen Installationsart nicht eingeloggt warst, kannst du dir einen Alt-Token von mcleaks.net holen.
	• Da du ja keinen normalen Minecraft Account hast, gibt es die Möglichkeit einen geleakten zu nehmen, oder dich beispielsweise mit einem Alt-Token von mcleaks.net zu verifizieren.
	• Klicke auf mcleaks.net in der Mitte auf den Button "MC Account jetzt erhalten", bestätige das reCAPCHA und es wird der Alt-Token angezeigt.
	• Diesen kopierst du in die Zwischenablage.
	• Gebe beim Benutzeraccount nun den Alt Code ein und irgend ein Passwort.
	• Wenn du dich so nicht anmelden kannst, gehe weiter zur letzten Installationsart.
	• Stelle ansonsten nun ein, dass du auf der viertneusten Version (Bzw. Version 1.12.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server".
	• Beim Servernamen, ist dir der Name selber überlassen.
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein.
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done".
	• Nun kannst du dem Server beitreten.

5.) • Wenn alle anderen Installationsarten gescheitert sind.
	• Auf der Seite mindecraft.lan-party.ml findest du unter dem Punkt: Hilfe ► Ich habe keinen Minecraft Account, geleakte Daten. Spreche dich allerdings mit anderen Spielern auf dem Server ab, dass ihr nicht die gleichen nehmt, weil ihr euch sonnst gegenseitig raus werft.
	• Melde dich damit bei Minecraft an.
	• Wenn das nicht klappt, probiere einen anderen Account aus. Wenn es mit keinem aller Accounts klappt, schaue unten bei Hilfe nach.
	• Wenn du dich einloggen konntest, stelle nun ein, dass du auf der viertneusten Version (Bzw. Version 1.12.2) spielen möchtest und klicke auf "Play".
	• Klicke auf Multiplayer und anschließend auf "Ad Server".
	• Beim Servernamen, ist dir der Name selber überlassen.
	• Bei der Server Adresse gibst du "nettom.ddnss.de" (ohne Anführungsstriche) ein.
	• Bei den Server Recource Packs, wählst du "Disabled" aus. Dies ist aber nicht so wichtig.
	• Klicke auf "Done".
	• Nun kannst du dem Server beitreten.
	
#####################################################################
Zusatzinstallation:

• Um das Spiel einfacher zu gestalten, gibt es die Möglichkeit einen Mod zu installieren, der auch auf dem Server Funktioniert.
• Das ganze, auf dem Server, ist dann immer noch Minecraft Vanilla, allerdings kannst du durch beispielsweise einen Klick auf dei Taste "R", dein Inventar sortieren.
• Schließe Minecraft vollständig.
• Gehe durch den Installationsvorgang der "forge.exe".
• Öffne anschließend den Ordner "/.minecraft/mods/" und kopiere die Datei "InventoryTweaks-1.63.jar" in diesen Ordner hinein.
• Starte Minecraft anschließend neu und wähle das Profil "1.12.2-forge1.12.2-14.23.5.2807" aus.

#####################################################################



#####################################################################
				Hilfe
#####################################################################
	Was tun, wenn keine Installationsart geklappt hat?
	• Alle Programme neu installieren.
	• Die Anleitung von oben nach unten Schritt für Schritt durchgehen.
	• Java Version überprüfen (Mindestens Version 8).
	• den "C:\Users\DEINNUTZERNAME\AppData\Roaming\.minecraft" Ordner löschen.
	• Probieren Minecraft in der Version 1.13.2 zu starten.
	• Wenn das alles nicht hilft, kann es sein, dass dein PC zu schlecht ist.
	• Lasse den Mod bzw. Forge weg.


©2019 Tom Aschmann V.1